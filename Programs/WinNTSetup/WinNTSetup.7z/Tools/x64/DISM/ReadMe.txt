Put latest ADK DISM or at least "api-ms-win-downlevel*.dll" files here,
to enable driver integration in Windows 8.1 while running Windows 7.